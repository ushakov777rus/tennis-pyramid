import MainPage from "./MainPage";

export default function Page() {
  return <MainPage />;
}